<?php

@header("Content-type: text/html; charset=UTF-8");

/**
 * www.arasjoomla.ir Joomla Extensions Developer
 * @author        arasjoomla.ir iran http://www.arasjoomla.ir
 * @copyright    Copyright (c) 2013 arasjoomla.ir iran Ltd. All rights reserved.
 * @license     GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link        http://arasjoomla.ir
 * @Link 		http://Afzoneha.com
 * @Email      Info@Afzoneha.com
 * ###################################################################
 * # Important: Do not rempove this copyright of ArasJoomla.ir & WWW.AFZONEHA.COM ####
*/
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.html.parameter' );

if (file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsmembership'.DS.'helpers'.DS.'rsmembership.php'))
	require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsmembership'.DS.'helpers'.DS.'rsmembership.php');

class plgSystemRSMembershipJahanpay extends JPlugin
{
	function canRun()
	{
		return file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsmembership'.DS.'helpers'.DS.'rsmembership.php');
	}

	function plgSystemRSMembershipJahanpay(&$subject, $config)
	{
		parent::__construct($subject, $config);
		if (!$this->canRun()) return;
		$this->_plugin =& JPluginHelper::getPlugin('system', 'rsmembershipjahanpay');
		$this->_params = json_decode($this->_plugin->params);
		RSMembership::addPlugin('Jahanpay RSMembership! Payment Plugin', 'rsmembershipjahanpay');
	}
	public function onAfterRender()
	{
		if(isset($_POST['trans_id']) && isset($_POST['id_get']))
		{
			$this->onPaymentNotification();
		}
	}
	function onMembershipPayment($plugin, $data, $extra, $membership, $transaction)
	{
		if (!$this->canRun()) return;
		if ($plugin != $this->_plugin->name) return false;
        $api = $this->params->get('api');
        $amount = $transaction->price;
        $transaction->custom = time(); /// set orderId
        $callBackUrl = JURI::base().'index.php?option=com_rsmembership&task=thankyou&custom='.$transaction->custom;
        $html = "";
        $result = $this->setJahanAdvanced($api,$amount,$callBackUrl,$transaction->custom); 
       
       if($result['result']==1){
           
            $session =& JFactory::getSession();
            $session->set('amount',$amount);
            $session->set('orderid',$transaction->custom);
            $session->set('au',$result['au']);
          
          $html .= '<div style="display:none;">'.$result['form'].'</div><script>document.forms[0].submit();</script>'; 
          $html .= '<button class="btn btn-block btn-success" style="margin-top: 8px;" type="submit">'.JText::_( 'در حال اتصال به بانک...!' ).'</button>'; 
           
       }else{
           
          $error = $this->getJahanErr($result['result']);  
          $html .= "خطایی رخ داده است :: شرح خطا: $error";  
        }
        
        return $html;

   }
   
  public function onPaymentNotification()
	{
		@header('Content-Type: text/html; charset=utf-8');
        $session =& JFactory::getSession();
		if (!$this->canRun()){
			echo ('خطایی در اجرای پلاگین رخ داده است');
		}else{
            
            
            $amount = $session->get('amount');
            $au = $session->get('au');
            $orderid = $session->get('orderid');
            $api = $this->params->get('api'); 

            $db = JFactory::getDBO();
            $query =  "SELECT id FROM #__rsmembership_transactions WHERE `custom`='".$orderid."' AND `status`!='completed' AND `gateway`='Jahanpay RSMembership! Payment Plugin'" ;
            $db->setQuery($query);
            $transaction = $db->loadResult();
            
            if($transaction){ 
                $res = $this->getJahanAdvanced($api,$amount,$au,$orderid);
                if($res['result'] == 1){
                    $bank_au = $res['bank_au'];
                    echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">با تشکر از شما :: پرداخت با موفقیت انجام شد.<br />شماره پیگیری : '.$bank_au.'<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
                    $sql = "UPDATE #__rsmembership_transactions SET `hash`='".$bank_au."' , `status`='completed' WHERE `id`='".$transaction->id."' LIMIT 1" ;
                    $db->setQuery($sql);
                    $db->query();
                    RSMembership::approve($transaction->id, true);
                    $session->clear('amount');
                    $session->clear('orderid');
                    $session->clear('au');
                    exit;die;
                    
                }else{
                    $session->clear('amount');
                    $session->clear('orderid');
                    $session->clear('au');  
                  echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">پرداخت شما ناموفق بوده و لغو شده است.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
                  exit;die;   
                }
            
            }else{
                $session->clear('amount');
                $session->clear('orderid');
                $session->clear('au');
                echo '<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">سفارش شما معتبر نیست و تراکنش شما لغو شده است</p>';
                exit;die;   
            }
          $session->clear('amount');
          $session->clear('orderid');
          $session->clear('au');
	}
    
    $session->clear('amount');
    $session->clear('orderid');
    $session->clear('au'); 
 }
 
 protected function setJahanAdvanced($api,$amount,$callBackUrl,$orderid){
     
        ini_set("soap.wsdl_cache_enabled", "0");
        $client = new SoapClient("http://www.jpws.me/directservice?wsdl");
        $res = $client->requestpayment($api,$amount,$callBackUrl,$orderid);
        return $res;
        
 } 
 
 protected function getJahanAdvanced($api,$amount,$au,$orderid){
     
        ini_set("soap.wsdl_cache_enabled", "0");
        $client = new SoapClient("http://www.jpws.me/directservice?wsdl");
        $res = $client->verification($api,$amount,$au,$orderid, $_POST + $_GET );
        return $res;
     
 } 
    
  protected function getJahanErr($num){
        
         $result = array(
                   '-32' => 'تراکنش انجام شده اما مبلغ مطابقت ندارد',
                   '-31' => 'تراکنش انجام نشده است',
                   '-30' => 'چنین تراکنشی موجود نیست',
                   '-29' => 'آدرس برگشتی خالی است',
                   '-27' => 'آی پی شما مسدود شده است',
                   '-26' => 'درگاه غیرفعال شده است',
                   '-24' => 'مبلغ نادرست است',
                   '-23' => 'مبلغ زیاد است',
                   '-22' => 'مبلغ کم است حداقل مبلغ ارسالی به درگاه 100 تومان میباشد',
                   '-21' => 'آی پی برای این درگاه نامعتبر است',
                   '-20' => 'API نادرست است',
                   '-6' => 'خطای اتصال به بانک',
                   '-9' => 'خطای سیستمی رخ داده است'
         );

        
        return $result[$num];
    }  
}